def bg():
    print('Welcome to the Brain Games!')

def main():
    bg()

if __name__ == '__main__':
    main()
