#!/usr/bin/env python3

import random


def random_num(r_one, r_two):
    r_num = random.randint(r_one, r_two)

    return r_num
